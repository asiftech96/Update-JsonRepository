package com.atechjson.json;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@Table(name = "Authenticators_test")
public class Authenticators {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer authenticatorsId;

	private String optional;
	private String regex;
	private String parameter_name;
	private String data_type;
	private String error_message;
	private String seq;

	@ManyToOne(cascade = CascadeType.REFRESH, targetEntity = Biller.class)
	@JoinColumn(name = "BillerID")
	private Biller biller;

	public Biller getBiller() {
		return biller;
	}

	public void setBiller(Biller biller) {
		this.biller = biller;
	}

	public Integer getAuthenticatorsId() {
		return authenticatorsId;
	}

	public void setAuthenticatorsId(Integer authenticatorsId) {
		this.authenticatorsId = authenticatorsId;
	}

	public String getOptional() {
		return optional;
	}

	public void setOptional(String optional) {
		this.optional = optional;
	}

	public String getRegex() {
		return regex;
	}

	public void setRegex(String regex) {
		this.regex = regex;
	}

	public String getParameter_name() {
		return parameter_name;
	}

	public void setParameter_name(String parameter_name) {
		this.parameter_name = parameter_name;
	}

	public String getData_type() {
		return data_type;
	}

	public void setData_type(String data_type) {
		this.data_type = data_type;
	}

	public String getError_message() {
		return error_message;
	}

	public void setError_message(String error_message) {
		this.error_message = error_message;
	}

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

}
