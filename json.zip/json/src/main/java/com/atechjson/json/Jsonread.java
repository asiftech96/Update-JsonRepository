package com.atechjson.json;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class Jsonread {

	@Autowired
	private BillerRepository billerRepository;

	@Test
	public void testBiller() {

		JSONParser jsonParser = new JSONParser();

		try (FileReader reader = new FileReader(
				"C:\\Users\\Salman\\Desktop\\Asif-jobwork\\HGA1F0A3990000021241.json")) {
			// Read JSON file
			Object obj = jsonParser.parse(reader);
//            JSONObject jsonObj = (JSONObject) obj;
			org.json.simple.JSONArray billerList = (org.json.simple.JSONArray) obj;
			System.out.println(billerList);

			// Iterate over biller array
			billerList.forEach(emp -> parseBillerObject((org.json.simple.JSONObject) emp));

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	private void parseBillerObject(org.json.simple.JSONObject biller) {
		Biller biller1 = new Biller();
		String objectid = (String) biller.get("objectid");
		String billerid = (String) biller.get("billerid");
		String biller_legal_name = (String) biller.get("biller_legal_name");
		String biller_name = (String) biller.get("biller_name");
		String biller_location = (String) biller.get("biller_location");
		String biller_category = (String) biller.get("biller_category");
		String biller_reg_address = (String) biller.get("biller_reg_address");
		String biller_reg_city = (String) biller.get("biller_reg_city");
		String biller_reg_pin = (String) biller.get("biller_reg_pin");
		String biller_reg_state = (String) biller.get("biller_reg_state");
		String biller_reg_country = (String) biller.get("biller_reg_country");
		String biller_mode = (String) biller.get("biller_mode");
		String biller_status = (String) biller.get("biller_status");
		String biller_created_date = (String) biller.get("biller_created_date");
		String biller_lastmodified_date = (String) biller.get("biller_lastmodified_date");
		String biller_logo = (String) biller.get("biller_logo");
		String biller_bill_copy = (String) biller.get("biller_bill_copy");
		String biller_type = (String) biller.get("biller_type");
		String partial_pay = (String) biller.get("partial_pay");
		String pay_after_duedate = (String) biller.get("pay_after_duedate");
		String online_validation = (String) biller.get("online_validation");
		String isbillerbbps = (String) biller.get("isbillerbbps");
		String paymentamount_validation = (String) biller.get("paymentamount_validation");
		String bbps_billerid = (String) biller.get("bbps_billerid");
		String bill_presentment = (String) biller.get("bill_presentment");

//	        Authenticators implementation
		String optional = null;
		String regex = null;
		String parameter_name = null;
		String data_type = null;
		String error_message = null;
		String seq = null;
		JSONObject obj = new JSONObject(biller);
		JSONArray schedule_Array = obj.getJSONArray("authenticators");
		List<Authenticators> authenticators = new ArrayList<Authenticators>();
		for (int j = 0; j < schedule_Array.length(); j++) {
			JSONObject jOBJNEW = schedule_Array.getJSONObject(j);
			optional = (String) jOBJNEW.get("optional");
			regex = (String) jOBJNEW.get("regex");
			parameter_name = (String) jOBJNEW.get("parameter_name");
			data_type = (String) jOBJNEW.get("data_type");
			error_message = (String) jOBJNEW.get("error_message");
			seq = (String) jOBJNEW.get("seq");

			Authenticators authenticators2 = new Authenticators();
			authenticators2.setOptional(optional);
			authenticators2.setRegex(regex);
			authenticators2.setParameter_name(parameter_name);
			authenticators2.setData_type(data_type);
			authenticators2.setError_message(error_message);
			authenticators2.setSeq(seq);
			authenticators.add(authenticators2);
			authenticators.get(j).setBiller(biller1);
		}

		biller1.setObjectid(objectid);
		biller1.setBillerid1(billerid);
		biller1.setBiller_legal_name(biller_legal_name);
		biller1.setBiller_name(biller_name);
		biller1.setBiller_location(biller_location);
		biller1.setBiller_category(biller_category);
		biller1.setBiller_reg_address(biller_reg_address);
		biller1.setBiller_reg_city(biller_reg_city);
		biller1.setBiller_reg_pin(biller_reg_pin);
		biller1.setBiller_reg_state(biller_reg_state);
		biller1.setBiller_reg_country(biller_reg_country);
		biller1.setBiller_mode(biller_mode);
		biller1.setBiller_status(biller_status);
		biller1.setBiller_created_date(biller_created_date);
		biller1.setBiller_lastmodified_date(biller_lastmodified_date);
		biller1.setBiller_logo(biller_logo);
		biller1.setBiller_bill_copy(biller_bill_copy);
		biller1.setBiller_type(biller_type);
		biller1.setPartial_pay(partial_pay);
		biller1.setPay_after_duedate(pay_after_duedate);
		biller1.setOnline_validation(online_validation);
		biller1.setIsbillerbbps(isbillerbbps);
		biller1.setPaymentamount_validation(paymentamount_validation);
		biller1.setBbps_billerid(bbps_billerid);
		biller1.setBill_presentment(bill_presentment);
		biller1.setAuthenticators(authenticators);
		billerRepository.save(biller1);
	}

}
